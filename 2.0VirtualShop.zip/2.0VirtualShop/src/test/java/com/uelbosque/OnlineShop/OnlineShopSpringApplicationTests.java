package com.uelbosque.OnlineShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShopSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
